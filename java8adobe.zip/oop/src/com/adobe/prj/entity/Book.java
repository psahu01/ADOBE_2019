package com.adobe.prj.entity;

import com.adobe.prj.util.Column;
import com.adobe.prj.util.Table;

@Table(name="books")
public class Book {
	private int id;
	private String title;
	/**
	 * @return the id
	 */
	@Column(name="book_id", type="NUMERIC(10)")
	public int getId() {
		return id;
	}
	/**
	 * @return the title
	 */
	@Column(name="book_title")
	public String getTitle() {
		return title;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
