package com.adobe.prj.client;

import com.adobe.prj.entity.Book;
import com.adobe.prj.entity.Mobile;
import com.adobe.prj.entity.Product;
import com.adobe.prj.entity.Tv;
import com.adobe.prj.util.Utility;

public class SortTest {

	public static void main(String[] args) {
		
		String SQL = Utility.createStatement(Book.class);
		System.out.println(SQL);
		
		String[] names = {"Danny","Lee","Angelina","Anna","George","Brad"};
		
		Utility.sort(names);
		
		for(String name : names) {
			System.out.println(name);
		}
		
		Product[] products = new Product[4];
		products[0] = new Tv(1, "Sony Bravia", 120000.00, "4HD");
		products[1] = new Mobile(2, "iPhone X", 130000.00, "4HD");
		products[2] = new Mobile(3, "One Plust 6t", 56000.00, "4G");
		products[3] = new Tv(4, "LG", 920000.00, "4HD");
		
		Utility.sort(products);
		
		for(Product p : products) {
			System.out.println(p);
		}
	}

}
