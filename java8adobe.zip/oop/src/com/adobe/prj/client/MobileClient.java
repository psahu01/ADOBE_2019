package com.adobe.prj.client;

import com.adobe.prj.dao.MobileDao;
import com.adobe.prj.dao.MobileDaoFactory;
import com.adobe.prj.entity.Mobile;

public class MobileClient {

	public static void main(String[] args) {
		Mobile m  = new Mobile(2, "iPhone X", 130000.00, "4HD");
//		MobileDao mobileDao = new MobileDaoFileImpl();
		MobileDao mobileDao = MobileDaoFactory.getMobileDao();
		mobileDao.addMobile(m);	
	}

}
