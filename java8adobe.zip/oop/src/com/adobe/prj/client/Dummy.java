package com.adobe.prj.client;

public class Dummy {

	public static void main(String[] args) {
		int x = 10;
		Integer iX = x; //boxing , wrapping
		int y = iX; // unboxing
	}

}
