package com.adobe.prj.dao;

import com.adobe.prj.entity.Mobile;

public interface MobileDao {
	void addMobile(Mobile m);
}
