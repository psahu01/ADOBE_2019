package com.adobe.prj.client;

import java.util.Arrays;

public class ArrayClient {

	public static void main(String[] args) {
		String[] names = { "Danny", "Lee", "Angelina", "Anna", "George", "Brad" };

//		Arrays.sort(names);
		Arrays.sort(names, (n1,n2) -> n1.length() - n2.length());
		for (String name : names) {
			System.out.println(name);
		}
	}

}
